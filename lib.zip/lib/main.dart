import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:workmanager/workmanager.dart';

import 'model/signup_form_model.dart';
import 'model/employee_signup_model.dart';
import 'core/splash_screen.dart';
import 'services/background_location_task.dart'; // Ensure callbackDispatcher is annotated

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ Check and request location permission before anything else
  LocationPermission permission = await Geolocator.checkPermission();

  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }

  if (permission == LocationPermission.deniedForever ||
      permission == LocationPermission.whileInUse) {
    // Open settings only in foreground (safe here)
    await Geolocator.openAppSettings();
    // You can optionally exit the app or show a dialog here
    return;
  }

  // ✅ Permissions are fine → Initialize WorkManager
  await Workmanager().initialize(
    callbackDispatcher,
    isInDebugMode: true,
  );

  // ✅ For testing: schedule task after 2 minutes
  await scheduleOneTimeTask(2);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SignupFormModel()),
        ChangeNotifierProvider(create: (_) => EmployeeSignupModel()),
      ],
      child: MaterialApp(
        title: 'Quick Roll',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
